package fabrik;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ConcreteCsvReaderProduct extends ReaderProduct {

	private BufferedReader ein;

	public ConcreteCsvReaderProduct() throws IOException {
		this.ein = new BufferedReader(new FileReader("Volkshochschulkurs.csv"));
	}

	@Override
	public String[] leseAusDatei() throws IOException {
		String[] ergebnisZeile = ein.readLine().split(";");
		return ergebnisZeile;
	}

	@Override
	public void schliesseDatei() throws IOException {
		ein.close();
	}
}
