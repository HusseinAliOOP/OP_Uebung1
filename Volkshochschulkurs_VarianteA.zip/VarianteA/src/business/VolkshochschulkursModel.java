package business;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import fabrik.ConcreteCsvReaderCreator;
import fabrik.ConcreteTxtReaderCreator;
import fabrik.ReaderCreator;
import fabrik.ReaderProduct;

public class VolkshochschulkursModel {
	Volkshochschulkurs volkshochschulkurs;


	public Volkshochschulkurs getVolkshochschulkurs() {
		return volkshochschulkurs;
	}

	public void setVolkshochschulkurs(Volkshochschulkurs volkshochschulkurs) {
		this.volkshochschulkurs = volkshochschulkurs;
	}

	public void leseVolkshochschulkursAusDatei(String typ) throws IOException{
		// Kreieren eines Creator-Objekts und Abspeicherung mit Hilfe
		// einer Variablen vom Typ der abstrakten Creator-Klasse.
		// Variante A: fuer jedes Dateiformat gibt es einen eigenen Creator
		ReaderCreator readerCreator;
		if("csv".equals(typ)){
			readerCreator = new ConcreteCsvReaderCreator();
		}
		else{
			readerCreator = new ConcreteTxtReaderCreator();
		}
		// Kreieren eines Product-Objekts mit Hilfe der Factory-Methode
		// und Abspeicherung in einer Variablen vom Typ der abstrakten
		// Product-Klasse
		ReaderProduct reader = readerCreator.factoryMethod();
		String[] zeile = reader.leseAusDatei();
		this.volkshochschulkurs = new Volkshochschulkurs(zeile[0],
			Integer.parseInt(zeile[1]),
			zeile[2],
			Float.parseFloat(zeile[3]),
			zeile[4].split("_"));
		reader.schliesseDatei();
	}

	public void schreibeVolkshochschulkursnInCsvDatei() throws IOException{
		BufferedWriter aus
			= new BufferedWriter(new FileWriter("VolkshochschulkurseAusgabe.csv", true));
		aus.write(volkshochschulkurs.gibVolkshochschulkursZurueck(';'));
		aus.close();

	}

}
