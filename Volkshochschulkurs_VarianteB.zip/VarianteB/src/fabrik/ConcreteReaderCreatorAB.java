package fabrik;

import java.io.IOException;

public class ConcreteReaderCreatorAB extends ReaderCreator {

	@Override
	public ReaderProduct factoryMethod(String typ) throws IOException {
		if("csv".equals(typ)) {
			return new ConcreteCsvReaderProduct();
		}
		else {
			return new ConcreteTxtReaderProduct();
		}
	}
}
