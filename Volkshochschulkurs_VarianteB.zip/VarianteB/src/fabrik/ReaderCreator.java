package fabrik;

import java.io.IOException;

public abstract class ReaderCreator {

	public abstract ReaderProduct factoryMethod(String typ) throws IOException;
}
